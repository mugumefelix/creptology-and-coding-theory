
GROUP MEMBERS
MUGUME FELIX 2024/U/MMU/BCS/01366
BIRUNGI BRENDAH 2024/U/MMU/BCS/00177

 VIGENèRE CIPHER IMPLEMENTATION

This is a Python implementation of the Vigenère cipher, a method of encrypting alphabetic text by using a simple form of polyalphabetic substitution.

 FEATURES
* Encrypt and decrypt text using a keyword
* Preserves case (uppercase/lowercase)
* Handles non-alphabetic characters by leaving them unchanged
* Simple command-line interface

 USAGE

 BASIC USAGE
Run the script and follow the prompts:
`bash
* python vigenere.py #for vigenere cipher implementation
* python main.py # for ZKP implem

 Zero-Knowledge Proof (ZKP) Implementation

Project Overview
* This project implements the Fiat-Shamir Zero-Knowledge Proof protocol, a cryptographic method that allows one party (the prover) to prove to another party (the verifier) that they know a secret without revealing any information about the secret itself.

 Key Features
* Interactive ZKP protocol implementation
* Modular design with separate prover and verifier components
* Command-line interface for demonstration
 Detailed error handling and input validation

Implementation Details
The implementation consists of several key components:
* main.py`: Entry point for the ZKP demo
* zkp_prover.py`: Implements the prover's logi
* zkp_verifier.py`: Implements the verifier's logic
* zkp_utils.py`: Utility functions
* zkp_demo.py`: Interactive demonstration of the protocol

 Getting Started
 Prerequisites
- Python 3.6 or higher

### Installation
1. Clone this repository
2. Navigate to the project directory:
   ```bash
   cd GROUP FOUR
   ```

### Running the ZKP Demo
To run the Zero-Knowledge Proof demonstration:

`bash
* python main.py
 Example Usage
When prompted, you'll need to provide:
1. A modulus `n` (product of two large primes, e.g., 21 = 3 * 7)
2. A public key `v` (e.g., 4)
3. Your secret `s` (must be relatively prime to n, e.g., 5)
4. Number of rounds to run (1-20)

The program will guide you through the ZKP protocol where you'll play the role of the Prover (Blue Flag) and respond to challenges from the Verifier (Red Flag).

 How It Works
1. **Setup Phase**: The prover selects a secret `s` and computes `v = s² mod n`
2. **Commitment**: The prover selects a random `r` and sends `x = r² mod n`
3. **Challenge**: The verifier sends a random bit `e` (0 or 1)
4. **Response**: The prover sends `y = r * s^e mod n`
5. **Verification**: The verifier checks if `y² ≡ x * v^e mod n`


