import math
from zkp_prover import ZKP_Prover
from zkp_verifier import ZKP_Verifier
from zkp_utils import print_round_header, print_section, get_valid_input

def run_zkp_demo():
    print("=== Zero-Knowledge Proof Demo ===")
    print("Defender (Blue Flag) - Prover")
    print("Attacker (Red Flag) - Verifier\n")
    
    # Get parameters from user
    print_section("setup")
    n = get_valid_input("Enter n (modulus, product of two large primes): ", int, min_val=2)
    v = get_valid_input(f"Enter v (verifier's public key, 1 <= v < {n}): ", int, min_val=1, max_val=n-1)
    s = get_valid_input(f"Enter your secret s (1 <= s < {n} and relatively prime to {n}): ", 
                       int, min_val=1, max_val=n-1)
    
    # Initialize prover and verifier
    prover = ZKP_Prover(n, v, s)
    verifier = ZKP_Verifier(n, v)
    
    # Get number of rounds
    num_rounds = get_valid_input("\nEnter number of rounds to run (1-20): ", int, min_val=1, max_val=20)
    
    successful_rounds = 0
    
    for round_num in range(1, num_rounds + 1):
        print_round_header(round_num, num_rounds)
        
        # Prover creates a commitment
        print_section("prover's commitment")
        print("[BLUE] Your turn to provide r:")
        x, r = prover.commit()
        print(f"[BLUE] You send commitment x = {x} to Red Flag")
        
        # Verifier sets the commitment
        verifier.set_commitment(x)
        
        # Get challenge e from user input
        while True:
            try:
                e = int(input("\n[BLUE] Enter challenge e (0 or 1) to send to Red Flag: "))
                if e not in [0, 1]:
                    print("❌ Error: Challenge must be 0 or 1")
                    continue
                break
            except ValueError:
                print("❌ Please enter a valid integer (0 or 1)")
        
        print(f"[BLUE] You send challenge e = {e} to Red Flag")
        
        # Prover responds to the challenge
        print_section("prover's response")
        try:
            y = prover.respond(e)
            print(f"Prover calculates y = ", end="")
            if e == 0:
                print(f"r = {r}")
            else:
                print(f"(r * s) mod n = ({r} * {s}) mod {n} = {y}")
            
            # Verifier verifies the proof
            print("\n[VERIFICATION]")
            print("They need to find s such that: s² ≡ x * v^e mod n")
            print(f"Which is: s² ≡ {x} * {v}^{e} mod {n}\n")
            
            # Show calculation steps for verification
            v_pow_e = pow(v, e, n)
            print(f"Step 1: Calculate v^e mod n = {v}^{e} mod {n} = {v_pow_e}")
            
            # Calculate right side of the equation (x * v^e) mod n
            right_side = (x * v_pow_e) % n
            print(f"Step 2: Calculate x * v^e mod n = {x} * {v_pow_e} mod {n} = {right_side}")
            
            # For e=1, show the full calculation of expected y²
            if e == 1:
                expected_y_squared = pow((r * s) % n, 2, n)
                print(f"Step 3: Expected y² mod n = (r * s)² mod n = ({r} * {s})² mod {n} = {expected_y_squared}")
            else:
                print(f"Step 3: Expected y² mod n = r² mod n = {r}² mod {n} = {pow(r, 2, n)}")
            
            print(f"\nVerification will pass if: y² mod {n} = {right_side}\n")
            
            # Show expected y before getting verifier's response
            print("\n" + "="*50)
            print("VERIFIER'S INSTRUCTIONS")
            print("="*50)
            
            if e == 0:
                expected_y = r
                print(f"\n🔵 [BLUE] For challenge e=0, you (Verifier) must send exactly:")
                print(f"   y = r = {r}")
            else:
                expected_y = (r * s) % n
                print(f"\n🔵 [BLUE] For challenge e=1, you (Verifier) must calculate and send:")
                print(f"   y = (r * s) mod n")
                print(f"   y = ({r} * {s}) mod {n}")
                print(f"   y = {expected_y}")
            
            # Calculate the expected y based on the challenge e
            expected_y = r if e == 0 else (r * pow(s, e, n)) % n
            
            # Show expected y and prompt for input
            print("\n🔴 [RED] Expected value of y:")
            if e == 0:
                print(f"   For e=0, expected y = r = {r}")
            else:
                print(f"   For e=1, expected y = (r * s) mod n = ({r} * {s}) mod {n} = {expected_y}")
            
            # Get verifier's response
            y_verifier = get_valid_input("\n[RED] Enter the Red Flag's response y: ", int)
            
            # Verify the proof
            left_side = pow(y_verifier, 2, n)
            
            # Calculate right side based on e
            if e == 0:
                # For e=0: y² ≡ x mod n
                right_side = x % n
                expected_left = pow(r, 2, n)  # y² should equal r² mod n
            else:  # e=1
                # For e=1: y² ≡ (x * v) mod n
                # But we need to ensure v = s² mod n
                v_calculated = pow(s, 2, n)
                right_side = (x * v_calculated) % n
                expected_left = pow((r * s) % n, 2, n)  # y² should equal (r*s)² mod n
            
            # Check if the provided y matches the expected y
            expected_y = r if e == 0 else (r * s) % n
            y_matches = (y_verifier == expected_y)
            
            # The actual check: y² ≡ (x * v^e) mod n
            is_valid = (left_side == right_side)
            
            print("\n" + "="*50)
            print("VERIFICATION PROCESS")
            print("="*50)
            
            print(f"\n1. Calculate y² mod n:")
            print(f"   {y_verifier}² mod {n} = {left_side}")
            
            print(f"\n2. Verification for e = {e}:")
            if e == 0:
                print(f"   For e=0, we expect:")
                print(f"   y = r = {r}")
                print(f"   y² mod n = {r}² mod {n} = {pow(r, 2, n)}")
                print(f"   x mod n = {x} mod {n} = {x % n}")
            else:  # e=1
                print(f"   For e=1, we expect:")
                print(f"   y = (r * s) mod n = ({r} * {s}) mod {n} = {(r * s) % n}")
                print(f"   y² mod n = (r*s)² mod n = ({r}*{s})² mod {n} = {pow((r * s) % n, 2, n)}")
                print(f"   x * v mod n = {x} * {v} mod {n} = {(x * v) % n}")
                print(f"   (where v = s² mod n = {s}² mod {n} = {pow(s, 2, n)})")
                print(f"   v^e mod n = {v}¹ mod {n} = {v}")
                print(f"   x * v^e mod n = {x} * {v} mod {n} = {right_side}")
                print(f"   (should equal (r * s)² mod n = ({r} * {s})² mod {n} = {pow((r * s) % n, 2, n)})")
            
            print("\n3. Verification Check:")
            print(f"   y² mod n = {left_side}")
            print(f"   x * v^e mod n = {right_side}")
            
            if is_valid:
                print("\n✅ VERIFICATION SUCCESS!")
                print(f"{left_side} ≡ {right_side} (mod {n})")
            else:
                print("\n❌ VERIFICATION FAILED!")
                print(f"{left_side} ≢ {right_side} (mod {n})")
                
                # Show what the expected y should have been
                if e == 0:
                    expected_y = r
                    print(f"\nFor e=0, expected y = r = {r}")
                else:
                    expected_y = (r * s) % n
                    print(f"\nFor e=1, expected y = (r * s) mod n = ({r} * {s}) mod {n} = {expected_y}")
                
                print(f"But received y = {y_verifier}")
                
                if e == 0:
                    print("\nFor e=0, make sure you entered the correct value of r")
                    print(f"Expected y = r = {r}")
                else:
                    print("\nFor e=1, the correct response should be:")
                    expected_y = (r * s) % n
                    print(f"y = (r * s) mod n")
                    print(f"y = ({r} * {s}) mod {n}")
                    print(f"y = {expected_y}")
                    print(f"y = (r * s) mod n = ({r} * {s}) mod {n} = {expected_y}")
                    print(f"Then y² mod n = {pow(expected_y, 2, n)}")
                    print(f"And x * v mod n = {x} * {v} mod {n} = {(x * v) % n}")
                
        except Exception as e:
            print(f"❌ Error during proof: {str(e)}")
    
    # Final result
    print("\n" + "="*50)
    print("FINAL RESULT")
    print("="*50)
    print(f"Successfully completed {successful_rounds} out of {num_rounds} rounds")
    
    if successful_rounds == num_rounds:
        print("🎉 The prover has successfully proven knowledge of the secret!")
    else:
        print("❌ The prover failed to prove knowledge of the secret.")

if __name__ == "__main__":
    run_zkp_demo()
