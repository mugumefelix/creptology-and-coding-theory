import random

class ZKP_Verifier:
    def __init__(self, n, v):
        """
        Initialize the ZKP Verifier (Attacker - Red Flag)
        Args:
            n: Modulus (product of two large primes)
            v: Verifier's public key (v = s^2 mod n)
        """
        self.n = n
        self.v = v
        self.x = None
    
    def set_commitment(self, x):
        """Set the commitment x received from the prover"""
        self.x = x
    
    def challenge(self):
        """Generate a random challenge e (0 or 1)"""
        return random.choice([0, 1])
    
    def verify(self, y, e):
        """
        Verify the proof: check if y² ≡ x * v^e mod n
        """
        if self.x is None:
            raise ValueError("Commitment x not set")
            
        left = pow(y, 2, self.n)
        right = (self.x * pow(self.v, e, self.n)) % self.n
        return left == right
