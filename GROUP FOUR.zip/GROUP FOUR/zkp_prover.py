import random
import math

class ZKP_Prover:
    def __init__(self, n=None, v=None, s=None):
        """
        Initialize the ZKP Prover (Defender - Blue Flag)
        Args:
            n: Modulus (product of two large primes)
            v: Verifier's public key
            s: Prover's secret
        """
        self.n = n
        self.v = v
        self.s = s  # Prover's secret
        self.r = None
        self.x = None
    
    def update_parameters(self, n, v):
        """Update the prover's parameters"""
        self.n = n
        self.v = v
        self.r = None
        self.x = None
    
    def commit(self):
        """
        Create a commitment (first message in the protocol)
        Returns:
            tuple: (x, r) where x is the commitment and r is the random number used
        """
        # Get r from user input
        while True:
            try:
                r_input = input(f"\n[BLUE] Enter r (1 < r < {self.n-1} and relatively prime to {self.n}): ")
                self.r = int(r_input)
                
                if self.r <= 1 or self.r >= self.n:
                    print(f"❌ r must be between 1 and {self.n-1}")
                    continue
                    
                if math.gcd(self.r, self.n) != 1:
                    print(f"❌ r must be relatively prime to {self.n}")
                    continue
                    
                break
                    
            except ValueError:
                print("❌ Please enter a valid integer")
        
        # Compute x = r² mod n
        self.x = pow(self.r, 2, self.n)
        print(f"[BLUE] Calculating x = r² mod n = {self.r}² mod {self.n} = {self.x}")
        
        return self.x, self.r
    
    def respond(self, e):
        """Generate response to the challenge e (0 or 1)"""
        if e not in [0, 1]:
            raise ValueError("Challenge must be 0 or 1")
            
        if e == 0:
            return self.r  # If e=0, return r
        else:
            # If e=1, return (r * s) mod n
            if self.s is None:
                raise ValueError("Secret not set")
            return (self.r * self.s) % self.n
