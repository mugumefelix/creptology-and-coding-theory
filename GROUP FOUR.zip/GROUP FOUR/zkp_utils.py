def print_round_header(round_num, total_rounds):
    """Print a formatted round header"""
    print("\n" + "="*50)
    print(f"ROUND {round_num} of {total_rounds}")
    print("="*50)

def print_section(title):
    """Print a section header"""
    print("\n" + "-"*20)
    print(f"{title.upper()}")
    print("-"*20)

def get_valid_input(prompt, input_type=int, min_val=None, max_val=None):
    """Get valid user input with optional min/max validation"""
    while True:
        try:
            value = input_type(input(prompt))
            if min_val is not None and value < min_val:
                print(f"Value must be at least {min_val}")
                continue
            if max_val is not None and value > max_val:
                print(f"Value must be at most {max_val}")
                continue
            return value
        except ValueError:
            print(f"Please enter a valid {input_type.__name__}")
