#!/usr/bin/env python3
"""
Zero-Knowledge Proof (ZKP) Demo
-----------------------------
This is the main entry point for the Fiat-Shamir Zero-Knowledge Proof demonstration.
"""

def main():
    print("="*50)
    print("Fiat-Shamir Zero-Knowledge Proof Demo")
    print("="*50)
    print("\nThis program demonstrates the Fiat-Shamir Zero-Knowledge Proof protocol.")
    print("\nRoles:")
    print("- Prover (Blue Flag): You will provide a secret and respond to challenges")
    print("- Verifier (Red Flag): The system will verify your knowledge of the secret")
    
    # Import here to avoid circular imports
    from zkp_demo import run_zkp_demo
    
    try:
        run_zkp_demo()
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user.")
    except Exception as e:
        print(f"\n❌ An error occurred: {str(e)}")
        print("Please check your inputs and try again.")
    
    print("\nThank you for using the Zero-Knowledge Proof Demo!")

if __name__ == "__main__":
    main()
