import string
from collections import Counter

def cipher(text, key, mode):
    """Encrypt or decrypt text using the Vigenère cipher with detailed steps."""
    alphabet = string.ascii_lowercase
    result = []
    key_index = 0
    key = key.lower()
    
    if mode == 'encrypt':
        print("\nENCRYPTION STEPS:")
        print("-" * 50)
        print(f"{'Char':<5} {'Key':<5} {'Char Pos':<10} {'Key Pos':<10} {'(c+k) mod 26':<15} Result")
        print("-" * 50)
    else:
        print("\nDECRYPTION STEPS:")
        print("-" * 60)
        print(f"{'Char':<5} {'Key':<5} {'Char Pos':<10} {'Key Pos':<10} {'(c-k) mod 26':<15} Result")
        print("-" * 60)
    
    for char in text:
        if char.lower() in alphabet:
            key_char = key[key_index % len(key)]
            shift = alphabet.index(key_char)
            char_lower = char.lower()
            if char_lower in alphabet:
                char_index = alphabet.index(char_lower)
                
                if mode == 'encrypt':
                    new_index = (char_index + shift) % 26
                    operation = f"({char_index} + {shift}) % 26 = {new_index}"
                else:  # decrypt
                    new_index = (char_index - shift) % 26
                    operation = f"({char_index} - {shift}) % 26 = {new_index}"
                
                new_char = alphabet[new_index]
                if char.isupper():
                    new_char = new_char.upper()
                
                # Print step details
                print(f"{char:<5} {key_char.upper() if char.isupper() else key_char:<5} "
                      f"{char_index:<10} {shift:<10} {operation:<15} → {new_char}")
                
                result.append(new_char)
                key_index += 1
        else:
            # For non-alphabetic characters, just add them to the result
            print(f"{char:<5} {'-':<5} {'-':<10} {'-':<10} {'-':<15} → {char}")
            result.append(char)
    
    return ''.join(result)

def frequency_analysis(text):
    """Perform frequency analysis on the given text."""
    # English letter frequencies (approximate percentages)
    english_freq = {
        'a': 8.2, 'b': 1.5, 'c': 2.8, 'd': 4.3, 'e': 13.0, 'f': 2.2,
        'g': 2.0, 'h': 6.1, 'i': 7.0, 'j': 0.15, 'k': 0.77, 'l': 4.0,
        'm': 2.4, 'n': 6.7, 'o': 7.5, 'p': 1.9, 'q': 0.095, 'r': 6.0,
        's': 6.3, 't': 9.1, 'u': 2.8, 'v': 0.98, 'w': 2.4, 'x': 0.15,
        'y': 2.0, 'z': 0.074
    }
    
    # Calculate frequencies in the given text
    text = text.lower()
    letters = [c for c in text if c in string.ascii_lowercase]
    if not letters:
        return "No letters to analyze."
        
    total_letters = len(letters)
    freq = {}
    for letter in string.ascii_lowercase:
        count = letters.count(letter)
        freq[letter] = (count / total_letters) * 100
    
    # Sort by frequency (descending)
    sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)
    
    # Prepare analysis result
    result = ["\nFrequency Analysis:", "Letter  Count   %    Expected %"]
    result.append("-" * 30)
    
    for letter, percentage in sorted_freq:
        count = letters.count(letter)
        expected = english_freq.get(letter, 0)
        result.append(f"{letter.upper()}:     {count:4d}  {percentage:5.2f}%  {expected:5.2f}%")
    
    return '\n'.join(result)

def analyze_ciphertext(ciphertext, key_length=None):
    """Analyze ciphertext and attempt to recover the key and plaintext.
    
    Returns:
        dict: A dictionary containing analysis results including:
            - 'key': The most likely key found
            - 'plaintext': Decrypted text using the found key
            - 'key_length': The length of the key
            - 'analysis': Detailed analysis for each key position
    """
    # English letter frequencies (in order from most to least common)
    english_freq_order = 'etaoinshrdlcumwfgypbvkjxqz'
    
    # Count letter frequencies in ciphertext
    letters = [c.lower() for c in ciphertext if c.isalpha()]
    if not letters:
        return {
            'key': None,
            'plaintext': None,
            'key_length': 0,
            'analysis': "No letters to analyze in the ciphertext."
        }
    
    total_letters = len(letters)
    freq = Counter(letters)
    
    # Calculate Index of Coincidence (IC)
    ic = sum(n * (n-1) for n in freq.values()) / (total_letters * (total_letters - 1)) if total_letters > 1 else 0
    
    # If key length is not provided, try to determine it using Kasiski examination
    if key_length is None:
        # Simple approach: find repeating sequences and their distances
        # This is a simplified version of Kasiski examination
        sequences = {}
        for i in range(len(letters) - 2):
            seq = ''.join(letters[i:i+3])
            if seq in sequences:
                sequences[seq].append(i)
            else:
                sequences[seq] = [i]
        
        # Find distances between repeating sequences
        distances = []
        for seq, positions in sequences.items():
            if len(positions) > 1:
                for i in range(1, len(positions)):
                    distances.append(positions[i] - positions[0])
        
        # Find common factors of distances (potential key lengths)
        def get_factors(n):
            return set(reduce(list.__add__, 
                           ([i, n//i] for i in range(1, int(n**0.5) + 1) if n % i == 0)))
        
        factor_counts = {}
        for d in distances:
            for f in get_factors(d):
                if f > 1:  # Ignore 1 as a factor
                    factor_counts[f] = factor_counts.get(f, 0) + 1
        
        # Get the most likely key length (most common factor)
        if factor_counts:
            key_length = max(factor_counts.items(), key=lambda x: x[1])[0]
            print(f"\nMost likely key length: {key_length} (based on {len(distances)} sequence distances)")
        else:
            # If no repeating sequences found, try common key lengths
            key_length = 3  # Default to 3 if no better guess
            print("\nNo repeating sequences found. Using default key length of 3.")
    
    print(f"\nAnalyzing with key length: {key_length}")
    
    # Split ciphertext into key_length separate Caesar ciphers
    groups = [[] for _ in range(key_length)]
    for i, c in enumerate(letters):
        groups[i % key_length].append(c)
    
    # For each group, find the most likely shift (part of the key)
    key = []
    analysis = []
    
    for group_idx, group in enumerate(groups):
        # Count letter frequencies in this group
        freq = {}
        for c in group:
            freq[c] = freq.get(c, 0) + 1
        
        # Find the most common letter in this group
        if not freq:
            most_common = 'e'  # Default if group is empty (shouldn't happen)
        else:
            most_common = max(freq.items(), key=lambda x: x[1])[0]
        
        # Try different possible shifts based on common English letters
        possible_shifts = [(ord(most_common) - ord(common_letter)) % 26 
                          for common_letter in english_freq_order[:5]]  # Try top 5 most common English letters
        
        # Score each possible shift
        best_shift = None
        best_score = float('-inf')
        
        for shift in possible_shifts:
            # Decrypt the group with this shift
            decrypted_group = []
            for c in group:
                decrypted_char = chr(((ord(c) - ord('a') - shift) % 26) + ord('a'))
                decrypted_group.append(decrypted_char)
            
            # Score the decrypted text
            score = score_text(''.join(decrypted_group))
            
            if score > best_score:
                best_score = score
                best_shift = shift
        
        key_char = chr(ord('a') + best_shift)
        key.append(key_char)
        
        # Store analysis for this position
        analysis.append({
            'position': group_idx + 1,
            'most_common_letter': most_common,
            'shift': best_shift,
            'key_char': key_char,
            'score': best_score
        })
    
    found_key = ''.join(key)
    print(f"\nMost likely key: {found_key}")
    
    # Decrypt using the found key
    print("\nDecrypting with key:", found_key)
    decrypted = cipher(ciphertext, found_key, 'decrypt')
    
    # Calculate the score of the decrypted text
    score = score_text(decrypted)
    
    # Prepare detailed analysis output
    analysis_output = [
        "\n=== Vigenère Cipher Analysis ===\n",
        f"Key Length: {key_length}",
        f"Found Key: {found_key}",
        "\nKey Position Analysis:",
        "Pos  Common  Shift  Key  Score",
        "---- ------  -----  ---  -----"
    ]
    
    for a in analysis:
        analysis_output.append(
            f"{a['position']:<4} {a['most_common_letter'].upper():<7} "
            f"{a['shift']:<6} {a['key_char'].upper():<4} {a['score']:.2f}"
        )
    
    analysis_output.extend([
        "\nDecrypted Text:",
        "-------------",
        decrypted,
        "\nAnalysis Score:",
        f"Score: {score:.2f} (higher is better, >0.05 is likely English)"
    ])
    
    # If we found a key through analysis, return those results
    if found_key:
        return {
            'key': found_key,
            'key_length': key_length,
            'plaintext': decrypted,
            'score': score,
            'analysis': '\n'.join(analysis_output)
        }
    
    # Fallback key recovery attempt if initial analysis didn't find a key
    result = []
    best_score = -1
    best_guess = None
    
    # Try to recover key using possible lengths
    possible_lengths = [key_length] if key_length else [3, 4, 5]  # Default to common key lengths
    
    for kl in possible_lengths[:2]:  # Try top 2 possible lengths
        try:
            recovered_key = recover_key(''.join(letters), kl)
            decrypted_text = cipher(ciphertext, recovered_key, 'decrypt')
            
            # Simple scoring based on common English letters
            common_letters = set('etaoin shrdlu')
            score = sum(1 for c in decrypted_text.lower() if c in common_letters)
            
            result.append(f"\nKey length: {kl}")
            result.append(f"Recovered key: {recovered_key.upper()}")
            result.append(f"Decrypted start: {decrypted_text[:100]}...")
            result.append("-" * 60)
            result.append(f"Decrypted text: {decrypted_text}")
            result.append(f"Confidence: {'★' * (score % 5 + 1)}/5")
            result.append("-"*60)
            
            if score > best_score:
                best_score = score
                best_guess = (recovered_key, decrypted_text)
        except Exception as e:
            result.append(f"Error trying key length {kl}: {str(e)}")
    
    if best_guess:
        result.append("\n" + "="*60)
        result.append("BEST GUESS")
        result.append("="*60)
        result.append(f"Most likely key: {best_guess[0].upper()}")
        result.append("-"*60)
        result.append("Decrypted message:")
        result.append("-"*60)
        result.append(best_guess[1])
        
        return {
            'key': best_guess[0],
            'key_length': len(best_guess[0]),
            'plaintext': best_guess[1],
            'score': best_score,
            'analysis': '\n'.join(result)
        }
    else:
        return {
            'key': None,
            'key_length': 0,
            'plaintext': None,
            'score': 0,
            'analysis': "The text appears random or could not be decrypted with the current methods."
        }

def score_text(text):
    """Score text based on English letter frequencies."""
    # English letter frequencies (from most to least common)
    freq_order = 'etaoinshrdlcumwfgypbvkjxqz'
    score = 0
    text = text.lower()
    
    # Check for common English words
    common_words = set(['the', 'and', 'have', 'that', 'for', 'you', 'with', 'say', 'this', 'they', 'but', 'was', 'not', 'have', 'from', 'are'])
    
    # Score based on frequency of common letters
    for i, c in enumerate(text):
        if c in freq_order:
            # Higher score for more common letters
            score += (26 - freq_order.index(c)) * 10
    
    # Bonus for common words
    words = ''.join(c if c.isalpha() or c == ' ' else ' ' for c in text).split()
    for word in words:
        if word.lower() in common_words and len(word) > 2:
            score += 100 * len(word)
    
    return score

def crack_vigenere(ciphertext, max_key_length=15):
    """Attempt to crack Vigenère cipher using frequency analysis."""
    ciphertext_clean = ''.join(c.lower() for c in ciphertext if c.isalpha())
    
    # Try different key lengths
    best_key = ""
    best_plaintext = ""
    best_score = -1
    
    for key_length in range(1, min(max_key_length, len(ciphertext_clean)) + 1):
        # For each position in the key
        key_guess = []
        
        for i in range(key_length):
            # Get every key_length-th character starting at position i
            group = ciphertext_clean[i::key_length]
            
            # Find the most likely shift for this position
            best_shift = 0
            best_shift_score = -1
            
            for shift in range(26):
                # Try decrypting with this shift
                decrypted = ''
                for c in group:
                    decrypted_char = chr(((ord(c) - ord('a') - shift) % 26) + ord('a'))
                    decrypted += decrypted_char
                
                # Score this decryption
                shift_score = score_text(decrypted)
                
                if shift_score > best_shift_score:
                    best_shift_score = shift_score
                    best_shift = shift
            
            key_guess.append(chr(best_shift + ord('a')))
        
        # Try the complete key
        current_key = ''.join(key_guess)
        decrypted = cipher(ciphertext, current_key, 'decrypt')
        current_score = score_text(decrypted)
        
        if current_score > best_score:
            best_score = current_score
            best_key = current_key
            best_plaintext = decrypted
    
    return best_key.upper(), best_plaintext

def main():
    print("Vigenère Cipher Tool")
    print("===================")
    while True:
        print("\nOptions:")
        print("1. Encrypt text")
        print("2. Decrypt text")
        print("3. Analyze ciphertext")
        print("4. Crack Vigenère cipher")
        print("5. Exit")
        
        choice = input("Enter your choice (1-5): ").strip()
        
        if choice == '1':
            text = input("Enter the text to encrypt: ")
            key = input("Enter the encryption key: ")
            if not key.isalpha():
                print("Error: Key must contain only letters.")
                continue
            print("\n" + "="*60)
            print(f"ENCRYPTING WITH KEY: {key.upper()}")
            print("="*60)
            encrypted = cipher(text, key, 'encrypt')
            print("\n" + "="*60)
            print("ENCRYPTION COMPLETE")
            print("="*60)
            print(f"\nEncrypted text: {encrypted}")
            
        elif choice == '2':
            text = input("Enter the text to decrypt: ")
            key = input("Enter the decryption key: ")
            if not key.isalpha():
                print("Error: Key must contain only letters.")
                continue
            print("\n" + "="*60)
            print(f"DECRYPTING WITH KEY: {key.upper()}")
            print("="*60)
            decrypted = cipher(text, key, 'decrypt')
            print("\n" + "="*60)
            print("DECRYPTION COMPLETE")
            print("="*60)
            print(f"\nDecrypted text: {decrypted}")
            
        elif choice == '3':
            text = input("Enter the ciphertext to analyze: ")
            if not any(c.isalpha() for c in text):
                print("Error: No letters to analyze in the ciphertext.")
                continue
                
            key_length = input("Enter the key length (press Enter to auto-detect): ").strip()
            if key_length.isdigit():
                key_length = int(key_length)
                if key_length < 1:
                    print("Key length must be at least 1. Auto-detecting...")
                    key_length = None
            else:
                key_length = None
                
            analysis = analyze_ciphertext(text, key_length)
            print(analysis)
            
        elif choice == '4':
            ciphertext = input("Enter the ciphertext to crack: ")
            if not any(c.isalpha() for c in ciphertext):
                print("Error: No letters to analyze in the ciphertext.")
                continue
                
            print("\n" + "="*60)
            print("ATTEMPTING TO CRACK VIGENÈRE CIPHER")
            print("="*60)
            
            print("\nAnalyzing ciphertext...")
            key, plaintext = crack_vigenere(ciphertext)
            
            print("\n" + "="*60)
            print("CRACKING RESULTS")
            print("="*60)
            print(f"\nMost likely key: {key}")
            print(f"\nDecrypted text:\n{plaintext}")
            
            # Check if the decrypted text makes sense
            print("\n" + "="*60)
            print("ANALYSIS")
            print("="*60)
            print(frequency_analysis(plaintext))
            
        elif choice == '5':
            print("Exiting...")
            break
            
        else:
            print("Invalid choice. Please enter a number between 1 and 5.")

if __name__ == "__main__":
    main()
